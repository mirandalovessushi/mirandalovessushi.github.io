// Example: A simple welcome message in the console
console.log("Welcome to my personal website!");
